package config

type LoginInfo struct {
	Username   string `json:"username"`
	StudentNum string `json:"studentNum"`
}
type JwtForm struct {
	Username   string `json:"username"`
	StudentNum string `json:"studentNum"`
	ImgUrl     string `json:"imgUrl"`
}

var WhiteStuNum = []string{
	"**",
}
