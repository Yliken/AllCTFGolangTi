package OSSConfig

const OSS_ACCESS_KEY_ID = "LTA***atZ"
const OSS_ACCESS_KEY_SECRET = "z0OS5Pcl***bG3H5F"
const EndPoint = "oss-cn-***yuncs.com"

var Whitelist = []string{"iamadmin", ""}
